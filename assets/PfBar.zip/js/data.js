var appName = $("html").attr("ng-app");
var app = angular.module(appName, []);

var video = [
	{
		"url": "images/video1.jpg",
		"name": "致青春 原来你还在这里",
		"introduce": "向青春致意，献给所有怀念青春的人"
	},
	{
		"url": "images/video2.jpg",
		"name": "花千骨",
		"introduce": "向青春致意，献给所有怀念青春的人"
	},
	{
		"url": "images/video3.jpg",
		"name": "美人私房菜",
		"introduce": "向青春致意，献给所有怀念青春的人"
	},
	{
		"url": "images/video4.jpg",
		"name": "青云志",
		"introduce": "向青春致意，献给所有怀念青春的人"
	},
	{
		"url": "images/video5.jpg",
		"name": "外科风云",
		"introduce": "向青春致意，献给所有怀念青春的人"
	},
];

app.controller("pfCtrl", function($scope, $timeout){
	// 初始为不显示
	$scope.showFlag = false;

	// 获取换台条信息
	try{
		$scope.pfInfo = $.parseJSON(java_ad.getPfInfo());
	}catch(e){
		$scope.pfInfo = {
			"pf_info": {
				"channel_lcn": "120",
				"channel_name": "江苏卫视",
				"vod_flag": "true",
				"cur_date": "20170323",
				"cur_time": "17:01",
				"epg_playlength": "60",
				"epg_playpos": "3",
				"has_epginfo": "yes",
				"epginfo_list": [{
					"play_period": "now",
					"epg_name": "新闻联播",
					"epg_start_time": "17:01",
					"epg_end_time": "17:51"
				},
				{
					"play_period": "next",
					"epg_name": "焦点访谈",
					"epg_start_time": "18:03",
					"epg_end_time": "18:51"

				}]
			}
		};
	}

	// 获取广告信息
	try{
		$scope.pfAdvertInfo = $.parseJSON(java_ad.getPfAdPicUrl());
	}catch(e){
		$scope.pfAdvertInfo = {
			"pf_advert_url":{
				"advert_nums": "2",
				"advert_list": [{
					"url": "images/ad1.png",
					"id": "1",
					"position": ""
				},
				{
					"url": "images/video1.jpg",
					"id": "2",
					"position": "",
					"name": "致青春 原来你还在这里",
					"introduce": "向青春致意，献给所有怀念青春的人"
				}]
			}
		};
	}

	// 初始化结束后显示pf条
	$scope.init = function(){
		// 加载pf条效果
		$.pf();

		// 显示pf条
		$timeout(function(){
			$scope.showFlag = true;
		}, 600);
	};

	$scope.progress = function(){
		var style = {};

		style.width = ($scope.pfInfo.pf_info.epg_playpos/$scope.pfInfo.pf_info.epg_playlength*100) + "%";

		return style;
	}
});

/** 更新pf换台条的当前后续epg信息 */
function updatePfEpgInfo(jsonEpgInfo){
	//转换成JSON对象
	console.log("==========entry updatePfEpgInfo");
	console.log("==========updatePfEpgInfo call params:" + jsonEpgInfo);
	console.log("==========param to string:" + JSON.stringify(jsonEpgInfo))
//	var EpgInfoObject = $.parseJSON(jsonEpgInfo);
	var EpgInfoObject = jsonEpgInfo;

	//通过controller来获取Angular应用
	var appElement = document.querySelector('[ng-controller=pfCtrl]');
	//获取$scope变量
	var $scope = angular.element(appElement).scope();

	//数据更新
	var vod_flag = $scope.pfInfo.pf_info.vod_flag;
	var has_epginfo = $scope.pfInfo.pf_info.has_epginfo;
	$scope.pfInfo.pf_info = EpgInfoObject.updatePfEpgInfo;
	$scope.pfInfo.pf_info.vod_flag = vod_flag;
	$scope.pfInfo.pf_info.has_epginfo = has_epginfo;

	//影片更新
	/*var index;
	while( index == undefined || $scope.pfAdvertInfo.pf_advert_url.advert_list[1].url == video[index].url){
		index = GetRandomNum(0, 4);
	}

	$scope.pfAdvertInfo.pf_advert_url.advert_list[1].url = video[index].url;
	$scope.pfAdvertInfo.pf_advert_url.advert_list[1].name = video[index].name;*/

	//广告更新
	if(EpgInfoObject.updatePfEpgInfo.home_ad.update_flag == "yes") {
		$("#pf .advert img:eq(0)").attr("src", EpgInfoObject.updatePfEpgInfo.home_ad.ad_url);
	}

	//同步到Angular控制器中，则需要调用$apply()方法
	$scope.$apply();

	/*var $video = $(".recommend_program .title")
	$video.find(".marquee li").css("width", "auto");
	if( $video.find(".marquee").innerWidth() < $video.find(".marquee li").innerWidth() ){
		$video.find(".marquee").marquee("update");
	}else{
		$video.find(".marquee").marquee("pause");
		$video.find(".marquee li").css("left", "0px");
		$video.find(".marquee li").css("width", "100%");
	}*/
}

/** 生成指定范围的随机数 */
function GetRandomNum(Min,Max)
{
	var Range = Max - Min;
	var Rand = Math.random();
	return(Min + Math.round(Rand * Range));
}
