$(function() {
	// 浏览器窗口大小
	var browseWidth=window.innerWidth
			|| document.documentElement.clientWidth
			|| document.body.clientWidth;

	var browseHeight=window.innerHeight
			|| document.documentElement.clientHeight
			|| document.body.clientHeight;

	// 所有的比例应该为当前屏幕大小/1280
	var fontRate = 1280/1280 * parseInt($("body").css("font-size"));
	$("#pf").width(1280);
	$("#pf").height(720*0.198);
	$("body").css("fontSize", fontRate + "px");


	// 监听键盘事件
	$(window).keydown(function(event){
		event = event? event: window.event;
		var controlKey = event.keyCode || event.which;

		switch (controlKey) {
			case 13: //enter
				$.pf.change(true);
				break;
			case 32: //space
				$.pf.change(false);
				break;
			case 37: //left arrow
				$.pf.change(false);
				break;
			case 39: //right arrow
				$.pf.change(true);
				break;
			case 38: //up arrow
				console.log("up key press!")
				break;
			case 40: // down arrow
				console.log("down key press!")
				break;
			default:
				console.log(controlKey);
		}
	});

	$.pf = function(){
		//初始化页面数据
		init();

		/** 内部函数：用于初始化页面布局 */
		function init(){
			// 当文字太长时，跑马灯形式显示
			$(".marquee").marquee({
				loop: -1
			});

			// 推荐节目需要居中显示
			var $video = $(".recommend_program");
			$video.find(".marquee li").css("width", "auto");
			if( $video.find(".marquee").innerWidth() < $video.find(".marquee li").innerWidth() ){
				$video.find(".marquee").marquee("update");
			}else{
				$video.find(".marquee").marquee("pause");
				$video.find(".marquee li").css("left", "0px");
				$video.find(".marquee li").css("width", "100%");
			}
		}

		// move功能变量
		var $container = $("#pf .container");
		var $modules = $("#pf .module");
		var totalModules = $("#pf .module").size();

		// 正在移动标志变量
		$container.data("currentlyMoving", true);

		// Set up "Current" panel and next and prev
		var curModule = 1;
		growUp(curModule - 1);

		/** 内部函数：焦点选中 */
		function growUp(index){
			// 判断焦点是否需要上浮
			if(index == 0){
				var top = 0;
			}else{
				var top = "-1.5rem";
			}

			$modules.eq(index)
			.addClass("focus")
			.animate({
				"top": top
			}, 500, function(){

				//推荐节目时显示介绍
				if(index == 1) {
					$modules.eq(index).find(".modal").show();
					// 推荐节目出现遮罩层时，停止动画
					var $video = $modules.eq(index);
					if( $video.find(".marquee").innerWidth() < $video.find(".marquee li").innerWidth() ){
						$(".recommend_program .title .marquee li").css("left", "0px");
						$(".recommend_program .title .marquee").marquee("pause");

						$(".recommend_program .introduce .marquee").marquee("update");
					}
				}else{
					$modules.eq(index).find(".marquee").marquee("update");
				}

				$container.data("currentlyMoving", false);
			});
		}

		/** 内部函数：焦点移除 */
		function returnToNormal(index){
			$modules.eq(index)
			.removeClass("focus")
			.css("top", "0");

			//推荐节目时去除遮罩层
			if(index == 1) {
				$modules.eq(index).find(".modal").hide();
				// 推荐节目出现遮罩层时，开始动画
				var $video = $modules.eq(index);
				if( $video.find(".title .marquee").innerWidth() < $video.find(".title .marquee li").innerWidth() ){
					$(".recommend_program .introduce .marquee li").css("left", "0px");
					$(".recommend_program .introduce .marquee").marquee("pause");

					$(".recommend_program .title .marquee").marquee("update");
				}
			}
		}

		/** 公开函数：焦点处理
		 *  @param direction true = right, false = left
		 */
		$.pf.change = function(direction){
			//if not at the first or last panel
			if((direction && !(curModule <= totalModules - 1)) || (!direction && curModule <= 1)) { return false; }

			//if not currently moving
			if ($container.data("currentlyMoving") == false) {
				$container.data("currentlyMoving", true);

				var next = direction ? curModule + 1 : curModule - 1;

				returnToNormal(curModule - 1);
				growUp(next - 1);

				curModule = next;
			}
		}

		// 公开函数，返回curModule
		$.pf.getCurModuleIndex = function() {
			return curModule;
		};
	};

	//通过controller来获取Angular应用
	var appElement = document.querySelector('[ng-controller=pfCtrl]');
	//获取$scope变量
	var $scope = angular.element(appElement).scope();
	//初始化显示
	$scope.init();

});

// 外部事件调用
function controlKey(advertCode, keyCode){
	var ret = false;

	switch(keyCode){
		case 19: // key up
			//window.location.href = window.location.href;
			break;
		case 20: // key down
			//window.location.href = window.location.href;
			break;
		case 21: // key left
			$.pf.change(false);
			ret = true;
			break;
		case 22: // key right
			$.pf.change(true);
			ret = true;
			break;
		case 4:
		case 67:
			java_ad.cancelAd(advertCode);
			ret = true;
			break;
		case 23: // key enter
			ret = showAdvert();
			break;
		case 24: // vol up
			break;
		case 25: // vol down
			break;
		default:
			console.log("other keyCode");
	}
	return ret;
}

function showAdvert() {
	var ret = false;
	var curModuleIndex = $.pf.getCurModuleIndex();
	if(curModuleIndex == 1) {
		ret = true;		
		java_ad.showView("com.sdt.dvbplay", "com.sdt.dvbplay.cable.ChannelActivity", 5000);
		console.log("epg status");
	} else if(curModuleIndex == 2) {
		ret = true;
		//java_ad.startApkByIntent("android.intent.action.VODBROWSER", "http://shop.skyworth.com/static/topic/newGoods.htm");
		console.log("rujia advertise");
	}
	return ret;
}
